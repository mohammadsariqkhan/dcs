
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Brain, Database, Shield, Zap, CheckCircle2, CloudCog, TrendingUp, Users, Award, Lightbulb } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import StatCard from '@/components/StatCard';
import TestimonialCard from '@/components/TestimonialCard';

const HomePage = () => {
  const testimonials = [
    {
      quote: 'DataCloud Solutions rebuilt our ML infrastructure from the ground up. We reduced model training time by 75% and deployed 4 new models in a single quarter.',
      name: 'Maya Chen',
      company: 'VP of Data, Meridian Labs',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1493882552576-fce827c6161e?q=80&w=150&h=150&fit=crop&crop=faces'
    },
    {
      quote: 'Migrating petabytes of legacy data to AWS seemed impossible. Their engineering team executed it flawlessly with zero downtime. A true partnership.',
      name: 'Raj Patel',
      company: 'CTO, Elm & Oak Financial',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1479800800845-03752b6188fa?q=80&w=150&h=150&fit=crop&crop=faces'
    },
    {
      quote: 'Their predictive analytics models transformed our supply chain. We now forecast demand with 94% accuracy, saving millions annually.',
      name: 'Sarah Jenkins',
      company: 'Director of Operations, Nexus Logistics',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1700902894527-c1ef530d814c?q=80&w=150&h=150&fit=crop&crop=faces'
    }
  ];

  const insights = [
    {
      title: 'The Future of MLOps in Enterprise Environments',
      category: 'Artificial Intelligence',
      image: 'https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5?q=80&w=600&auto=format&fit=crop',
      date: 'Oct 12, 2025'
    },
    {
      title: 'Migrating Legacy Data Warehouses to Snowflake',
      category: 'Data Engineering',
      image: 'https://images.unsplash.com/photo-1516383274235-5f42d6c6426d?q=80&w=600&auto=format&fit=crop',
      date: 'Sep 28, 2025'
    },
    {
      title: 'Building Resilient Real-Time Streaming Pipelines',
      category: 'Cloud Architecture',
      image: 'https://images.unsplash.com/photo-1686061592689-312bbfb5c055?q=80&w=600&auto=format&fit=crop',
      date: 'Sep 15, 2025'
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col"
    >
      <Helmet>
        <title>DataCloud Solutions | Enterprise Data & AI Consulting</title>
        <meta name="description" content="Transform your business with intelligent data pipelines, scalable cloud architecture, and applied AI solutions." />
      </Helmet>

      <Header />

      <main className="flex-grow">
        {/* HERO SECTION */}
        <section className="relative min-h-[100dvh] flex items-center pt-20 overflow-hidden">
          <div 
            className="absolute inset-0 z-0 parallax-bg"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5?q=80&w=2500&auto=format&fit=crop)' }}
          >
            <div className="gradient-overlay" />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
          </div>

          <div className="container-custom relative z-10 pt-12 pb-24">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="max-w-3xl text-white"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 backdrop-blur-md mb-6">
                <span className="flex w-2 h-2 rounded-full bg-secondary animate-pulse" />
                <span className="text-sm font-medium tracking-wide">Enterprise Data & AI Partner</span>
              </div>
              
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold mb-6 text-white leading-tight">
                Architecting the <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">Intelligent Enterprise</span>
              </h1>
              
              <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl leading-relaxed">
                We engineer scalable data foundations and deploy applied AI models that turn raw information into your most powerful competitive advantage.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="h-14 px-8 text-base bg-primary hover:bg-primary/90 text-white rounded-full shadow-[0_0_40px_-10px_rgba(0,102,204,0.5)] transition-all duration-300 hover:-translate-y-1 hover:scale-105">
                  <Link to="/services">Explore Solutions</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="h-14 px-8 text-base rounded-full bg-white/5 border-white/20 text-white hover:bg-white/10 hover:text-white backdrop-blur-sm transition-all duration-300 hover:-translate-y-1">
                  <Link to="/contact">Schedule Consultation</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* METRICS SECTION */}
        <section className="py-16 -mt-24 relative z-20">
          <div className="container-custom">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
              <StatCard number="150+" label="Projects Delivered" icon={CheckCircle2} index={0} />
              <StatCard number="99%" label="Uptime Achieved" icon={CloudCog} index={1} />
              <StatCard number="12+" label="Industries Served" icon={Database} index={2} />
              <StatCard number="40%" label="Avg. Cost Reduction" icon={Zap} index={3} />
            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* WHY CHOOSE US */}
        <section className="py-24 bg-background">
          <div className="container-custom">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-primary font-semibold tracking-wide uppercase text-sm mb-3">Why Choose Us</h2>
              <h3 className="text-3xl md:text-5xl font-bold mb-6">Expertise that drives results</h3>
              <p className="text-lg text-muted-foreground">We combine deep technical knowledge with strategic business acumen to deliver solutions that matter.</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: Brain, title: 'Deep Expertise', desc: 'Our team consists of senior engineers and data scientists with enterprise experience.' },
                { icon: Lightbulb, title: 'Innovation First', desc: 'We leverage cutting-edge technologies to build future-proof architectures.' },
                { icon: TrendingUp, title: 'Proven Track Record', desc: 'Over 150 successful enterprise deployments across multiple industries.' },
                { icon: Users, title: 'Client Success', desc: 'We partner closely with your team to ensure seamless adoption and ROI.' }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 rounded-2xl bg-card border border-border shadow-soft-sm hover:shadow-soft-xl transition-all duration-300 hover:-translate-y-2 group"
                >
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                    <item.icon className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-bold mb-3">{item.title}</h4>
                  <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* TESTIMONIALS */}
        <section className="py-24 bg-slate-50 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/3 pointer-events-none" />
          <div className="container-custom relative z-10">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-6">Trusted by data leaders</h2>
              <p className="text-lg text-muted-foreground">
                We partner with technical teams at leading enterprises to accelerate their data maturity and drive measurable outcomes.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <TestimonialCard key={index} {...testimonial} index={index} />
              ))}
            </div>
          </div>
        </section>

        {/* LATEST INSIGHTS */}
        <section className="py-24 bg-background">
          <div className="container-custom">
            <div className="flex justify-between items-end mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Latest Insights</h2>
                <p className="text-lg text-muted-foreground">Perspectives from our engineering team.</p>
              </div>
              <Button variant="ghost" className="hidden md:flex group">
                View All Articles <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {insights.map((post, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="group cursor-pointer"
                >
                  <div className="relative h-64 rounded-2xl overflow-hidden mb-6 shadow-soft-md">
                    <div className="absolute inset-0 bg-slate-900/20 group-hover:bg-transparent transition-colors duration-300 z-10" />
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute top-4 left-4 z-20">
                      <span className="px-3 py-1 text-xs font-semibold bg-white/90 backdrop-blur-sm text-primary rounded-full">
                        {post.category}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{post.date}</p>
                  <h3 className="text-xl font-bold group-hover:text-primary transition-colors">{post.title}</h3>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA SECTION */}
        <section className="py-24 relative overflow-hidden">
          <div 
            className="absolute inset-0 parallax-bg"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa?q=80&w=2000&auto=format&fit=crop)' }}
          >
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" />
          </div>
          <div className="container-custom relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto text-center text-white"
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">Ready to modernize your data stack?</h2>
              <p className="text-xl text-slate-300 mb-10">
                Book a discovery call with our principal architects to discuss your infrastructure bottlenecks and AI roadmap.
              </p>
              <Button asChild size="lg" className="h-14 px-8 text-lg bg-white text-slate-900 hover:bg-white/90 rounded-full transition-all duration-300 hover:scale-105 shadow-soft-xl">
                <Link to="/contact">Schedule an Architecture Review</Link>
              </Button>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </motion.div>
  );
};

export default HomePage;
