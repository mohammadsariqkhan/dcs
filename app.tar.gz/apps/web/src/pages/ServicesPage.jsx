
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Brain, Database, BarChart3, CloudCog, ArrowRight, Code2, Server, Workflow, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ServiceCard from '@/components/ServiceCard';

const ServicesPage = () => {
  const mainServices = [
    {
      icon: Brain,
      title: 'Applied AI & Machine Learning',
      description: 'Move beyond proof-of-concepts. We design, train, and deploy robust ML models that integrate seamlessly into your production environments to automate complex decisions.',
      benefits: ['Predictive demand forecasting', 'Custom LLM integrations', 'Computer vision systems'],
      technologies: ['TensorFlow', 'PyTorch', 'HuggingFace', 'MLflow'],
      image: 'https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5?q=80&w=800&auto=format&fit=crop'
    },
    {
      icon: Database,
      title: 'Data Science',
      description: 'Extract actionable insights through statistical modeling, forecasting, and advanced analytics to drive strategic business decisions.',
      benefits: ['Statistical modeling', 'Customer segmentation', 'Risk assessment'],
      technologies: ['Python', 'R', 'Scikit-learn', 'Pandas'],
      image: 'https://images.unsplash.com/photo-1596774419796-0318e0ab4ba1?q=80&w=800&auto=format&fit=crop'
    },
    {
      icon: BarChart3,
      title: 'Data Analytics',
      description: 'Transform raw data into visual dashboards, KPI tracking, and self-service analytics platforms for real-time business intelligence.',
      benefits: ['Real-time reporting', 'Performance tracking', 'Interactive dashboards'],
      technologies: ['Power BI', 'Tableau', 'Looker', 'SQL'],
      image: 'https://images.unsplash.com/photo-1516383274235-5f42d6c6426d?q=80&w=800&auto=format&fit=crop'
    },
    {
      icon: Workflow,
      title: 'Data Engineering',
      description: 'Build scalable data pipelines, warehouses, and real-time streaming architectures that form the foundation of your data strategy.',
      benefits: ['Automated data flows', 'Scalable infrastructure', 'Data quality assurance'],
      technologies: ['Spark', 'Kafka', 'Databricks', 'Snowflake'],
      image: 'https://images.unsplash.com/photo-1667984390553-7f439e6ae401?q=80&w=800&auto=format&fit=crop'
    },
    {
      icon: CloudCog,
      title: 'Cloud Solutions',
      description: 'Migrate and modernize applications on leading cloud platforms with DevOps automation and robust security architectures.',
      benefits: ['Cost optimization', 'Infinite scalability', 'High availability'],
      technologies: ['AWS', 'Azure', 'GCP', 'Terraform'],
      image: 'https://images.unsplash.com/photo-1695668548342-c0c1ad479aee?q=80&w=800&auto=format&fit=crop'
    },
    {
      icon: Shield,
      title: 'Advanced Analytics',
      description: 'Go beyond descriptive analytics with predictive and prescriptive insights using optimization algorithms and decision science.',
      benefits: ['Decision optimization', 'Resource allocation', 'Risk mitigation'],
      technologies: ['Linear programming', 'Simulation', 'Neural networks'],
      image: 'https://images.unsplash.com/photo-1516383274235-5f42d6c6426d?q=80&w=800&auto=format&fit=crop'
    }
  ];

  const techStack = [
    { name: 'Python', icon: Code2 },
    { name: 'SQL', icon: Database },
    { name: 'Spark', icon: Zap },
    { name: 'Databricks', icon: Box },
    { name: 'Kafka', icon: Activity },
    { name: 'Snowflake', icon: Snowflake },
    { name: 'Azure', icon: Cloud },
    { name: 'AWS', icon: Cloud },
    { name: 'GCP', icon: Cloud },
    { name: 'TensorFlow', icon: Brain },
    { name: 'PyTorch', icon: Brain },
    { name: 'Power BI', icon: BarChart3 },
    { name: 'Tableau', icon: PieChart }
  ];

  // Fallback icons for tech stack since some specific brand icons aren't in lucide
  function Zap(props) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg> }
  function Box(props) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg> }
  function Activity(props) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg> }
  function Snowflake(props) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="2" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="22"/><path d="m20 16-4-4 4-4"/><path d="m4 8 4 4-4 4"/><path d="m16 4-4 4-4-4"/><path d="m8 20 4-4 4 4"/></svg> }
  function Cloud(props) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/></svg> }
  function PieChart(props) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg> }

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col"
    >
      <Helmet>
        <title>Solutions & Capabilities | DataCloud Solutions</title>
        <meta name="description" content="Explore our enterprise consulting services: Applied AI, Data Engineering, Cloud Architecture, and Advanced Analytics." />
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        {/* HEADER SECTION */}
        <section className="relative py-24 lg:py-32 overflow-hidden bg-slate-950">
          <div 
            className="absolute inset-0 z-0 parallax-bg opacity-40"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1695668548342-c0c1ad479aee?q=80&w=2000&auto=format&fit=crop)' }}
          >
            <div className="gradient-overlay" />
          </div>
          
          <div className="container-custom relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <h1 className="text-white mb-6">
                Engineering the <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Data-Driven</span> Enterprise
              </h1>
              <p className="text-xl text-slate-300 leading-relaxed mb-8">
                From scalable cloud foundations to predictive AI models, our capabilities cover the entire data lifecycle. We don't just build software; we architect competitive advantages.
              </p>
            </motion.div>
          </div>
        </section>

        {/* SERVICES GRID */}
        <section className="py-24 bg-background">
          <div className="container-custom">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
              {mainServices.map((service, index) => (
                <ServiceCard
                  key={index}
                  {...service}
                  index={index}
                  onCTAClick={() => window.location.href = '/contact'}
                />
              ))}
            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* TECHNOLOGIES */}
        <section className="py-24 bg-slate-50">
          <div className="container-custom text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Technology Stack</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-16">
              We leverage industry-leading tools and platforms to build robust, scalable, and secure data architectures.
            </p>
            
            <div className="flex flex-wrap justify-center gap-6 max-w-5xl mx-auto">
              {techStack.map((tech, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center gap-3 px-6 py-4 bg-card border border-border rounded-2xl shadow-soft-sm hover:shadow-soft-md transition-all hover:-translate-y-1"
                >
                  <tech.icon className="w-6 h-6 text-primary" />
                  <span className="font-semibold text-foreground">{tech.name}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA BANNER */}
        <section className="py-24 bg-muted border-t border-border">
          <div className="container-custom text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-2xl mx-auto"
            >
              <h2 className="mb-6 text-3xl md:text-4xl font-bold">Need a custom architecture?</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Every enterprise ecosystem is unique. Connect with our engineering leadership to map out an infrastructure plan tailored to your specific scale and compliance requirements.
              </p>
              <Button asChild size="lg" className="rounded-full h-14 px-8 text-base shadow-soft-md hover:-translate-y-1 hover:scale-105 transition-all duration-300">
                <Link to="/contact">Speak with an Architect</Link>
              </Button>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </motion.div>
  );
};

export default ServicesPage;
