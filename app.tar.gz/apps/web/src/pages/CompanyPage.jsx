
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Globe, Building, Award, Target, Eye, Users, ShieldCheck } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const CompanyPage = () => {
  const leadership = [
    {
      name: 'Anika Bergström',
      role: 'Chief Executive Officer',
      image: 'https://images.unsplash.com/photo-1493882552576-fce827c6161e?q=80&w=500&auto=format&fit=crop',
      bio: 'Former VP of Data Science at a Fortune 500 tech company. 15+ years leading data transformation initiatives.',
    },
    {
      name: 'Raj Patel',
      role: 'Chief Technology Officer',
      image: 'https://images.unsplash.com/photo-1479800800845-03752b6188fa?q=80&w=500&auto=format&fit=crop',
      bio: 'Ex-Google ML engineer with expertise in distributed systems and cloud architecture. PhD in Computer Science.',
    },
    {
      name: 'Maya Chen',
      role: 'VP of Data Engineering',
      image: 'https://images.unsplash.com/photo-1700902894527-c1ef530d814c?q=80&w=500&auto=format&fit=crop',
      bio: 'Built data platforms processing 10B+ events daily. Previously at Uber and Airbnb.',
    }
  ];

  const milestones = [
    { year: '2014', event: 'Company founded by data science veterans in San Francisco' },
    { year: '2016', event: 'Reached 10 enterprise clients, expanded to cloud services' },
    { year: '2018', event: 'Opened New York office, launched ML practice' },
    { year: '2020', event: 'Achieved AWS and Azure premier partner status' },
    { year: '2022', event: 'Delivered 100th project, expanded to 50+ clients globally' },
    { year: '2024', event: 'Launched generative AI practice, Databricks elite partnership' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col"
    >
      <Helmet>
        <title>Company & Global Presence | DataCloud Solutions</title>
        <meta name="description" content="Discover our global offices, technology partnerships, and company history." />
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        
        {/* HERO */}
        <section className="relative py-24 lg:py-32 overflow-hidden bg-slate-950">
          <div 
            className="absolute inset-0 z-0 parallax-bg opacity-40"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3?q=80&w=2000&auto=format&fit=crop)' }}
          >
            <div className="gradient-overlay" />
          </div>
          
          <div className="container-custom relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <h1 className="text-white mb-6">Global reach.<br/>Focused execution.</h1>
              <p className="text-xl text-slate-300 leading-relaxed">
                From our headquarters in San Francisco to our engineering hubs worldwide, we maintain a cohesive standard of technical excellence.
              </p>
            </motion.div>
          </div>
        </section>

        {/* VALUES */}
        <section className="py-24 bg-background">
          <div className="container-custom">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Values</h2>
              <p className="text-lg text-muted-foreground">The principles that guide our decisions and shape our culture.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: Target, title: 'Mission-Driven', desc: 'We focus on outcomes, not just outputs.' },
                { icon: Eye, title: 'Visionary', desc: 'Anticipating the future of data technology.' },
                { icon: Users, title: 'Collaborative', desc: 'Winning as a team, succeeding with clients.' },
                { icon: ShieldCheck, title: 'Integrity', desc: 'Uncompromising standards in security and ethics.' }
              ].map((val, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 rounded-2xl bg-card border border-border shadow-soft-sm hover:shadow-soft-lg transition-all duration-300 text-center group"
                >
                  <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                    <val.icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{val.title}</h3>
                  <p className="text-muted-foreground">{val.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* LEADERSHIP */}
        <section className="py-24 bg-slate-50">
          <div className="container-custom">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Leadership Team</h2>
              <p className="text-lg text-muted-foreground">Experienced leaders driving innovation and client success.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {leadership.map((leader, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-card text-card-foreground rounded-3xl overflow-hidden shadow-soft-md hover:shadow-soft-xl transition-all duration-300 group"
                >
                  <div className="h-64 overflow-hidden">
                    <img 
                      src={leader.image} 
                      alt={leader.name}
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                    />
                  </div>
                  <div className="p-8">
                    <h3 className="text-2xl font-bold mb-1">{leader.name}</h3>
                    <p className="text-primary font-medium mb-4">{leader.role}</p>
                    <p className="text-muted-foreground leading-relaxed">{leader.bio}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* TIMELINE */}
        <section className="py-24 bg-background">
          <div className="container-custom">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Journey</h2>
              <p className="text-lg text-muted-foreground">Key milestones in our growth and evolution.</p>
            </div>

            <div className="max-w-3xl mx-auto relative">
              <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-border -translate-x-1/2" />
              {milestones.map((milestone, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className={`relative flex items-center justify-between mb-12 last:mb-0 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
                >
                  <div className="hidden md:block w-5/12" />
                  <div className="absolute left-8 md:left-1/2 w-4 h-4 rounded-full bg-primary border-4 border-background -translate-x-1/2 z-10 shadow-sm" />
                  <div className="w-full md:w-5/12 pl-16 md:pl-0">
                    <div className={`p-6 bg-card border border-border rounded-2xl shadow-soft-sm hover:shadow-soft-md transition-shadow ${index % 2 === 0 ? 'md:text-left' : 'md:text-right'}`}>
                      <span className="text-2xl font-bold text-primary mb-2 block">{milestone.year}</span>
                      <p className="text-muted-foreground leading-relaxed">{milestone.event}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* PARTNERSHIPS & GLOBAL */}
        <section className="py-24 bg-slate-50">
          <div className="container-custom">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <Award className="w-12 h-12 text-secondary mb-6" />
                <h2 className="text-3xl md:text-4xl font-bold mb-6">Elite Technology Partnerships</h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  We hold premier certification tiers with the tools and platforms that define the modern data stack.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {['AWS Advanced Partner', 'Microsoft Azure Gold', 'Google Cloud Premier', 'Databricks Elite'].map((cert, i) => (
                    <div key={i} className="bg-card border border-border font-medium text-center p-4 rounded-xl shadow-soft-sm">
                      {cert}
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="relative rounded-3xl overflow-hidden shadow-soft-xl h-[400px]"
              >
                <img 
                  src="https://images.unsplash.com/photo-1643101807331-21a4a3f081d5?q=80&w=1200&auto=format&fit=crop"
                  alt="Global network connectivity visualization"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center">
                  <div className="text-center text-white p-8">
                    <Globe className="w-12 h-12 mx-auto mb-4 text-primary" />
                    <h3 className="text-2xl font-bold mb-2">Global Presence</h3>
                    <p className="text-slate-200">Serving enterprise clients across North America, Europe, and Asia-Pacific.</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </motion.div>
  );
};

export default CompanyPage;
