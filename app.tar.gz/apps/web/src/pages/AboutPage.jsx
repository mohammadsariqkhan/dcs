
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Users, Code2, Rocket, CheckCircle, Award } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const AboutPage = () => {
  const team = [
    {
      name: 'Anika Bergström',
      role: 'CEO & Principal Architect',
      image: 'https://images.unsplash.com/photo-1493882552576-fce827c6161e?q=80&w=500&auto=format&fit=crop'
    },
    {
      name: 'Raj Patel',
      role: 'Head of Applied AI',
      image: 'https://images.unsplash.com/photo-1479800800845-03752b6188fa?q=80&w=500&auto=format&fit=crop'
    },
    {
      name: 'Maya Chen',
      role: 'VP of Data Engineering',
      image: 'https://images.unsplash.com/photo-1700902894527-c1ef530d814c?q=80&w=500&auto=format&fit=crop'
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col"
    >
      <Helmet>
        <title>About Us | DataCloud Solutions</title>
        <meta name="description" content="Meet the team of specialized data engineers, scientists, and cloud architects driving enterprise innovation." />
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        {/* HERO */}
        <section className="relative py-24 lg:py-32 overflow-hidden bg-slate-950">
          <div 
            className="absolute inset-0 z-0 parallax-bg opacity-40"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3?q=80&w=2000&auto=format&fit=crop)' }}
          >
            <div className="gradient-overlay" />
          </div>
          
          <div className="container-custom relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <h1 className="text-white mb-6">Building the infrastructure of tomorrow.</h1>
              <p className="text-xl text-slate-300 leading-relaxed">
                DataCloud Solutions is an elite consulting firm comprised of former FAANG engineers and data scientists. We exist to solve the hardest technical scaling challenges for the world's most ambitious companies.
              </p>
            </motion.div>
          </div>
        </section>

        {/* CULTURE IMAGES */}
        <section className="py-24 bg-background">
          <div className="container-custom">
            <div className="text-center mb-16 max-w-2xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Culture</h2>
              <p className="text-lg text-muted-foreground">An environment built for deep work, continuous learning, and collaborative problem-solving.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <motion.div 
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="relative h-96 rounded-3xl overflow-hidden shadow-soft-xl group"
              >
                <div className="absolute inset-0 bg-slate-900/20 group-hover:bg-transparent transition-colors duration-500 z-10" />
                <img 
                  src="https://images.unsplash.com/photo-1607615896122-6c919f897e55?q=80&w=1000&auto=format&fit=crop"
                  alt="Engineering team collaborating in modern office"
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                />
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="relative h-96 rounded-3xl overflow-hidden shadow-soft-xl group"
              >
                <div className="absolute inset-0 bg-slate-900/20 group-hover:bg-transparent transition-colors duration-500 z-10" />
                <img 
                  src="https://images.unsplash.com/photo-1637622124152-33adfabcc923?q=80&w=1000&auto=format&fit=crop"
                  alt="Technical discussion around a monitor"
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                />
              </motion.div>
            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* APPROACH */}
        <section className="py-24 bg-slate-50">
          <div className="container-custom">
            <div className="text-center mb-16 max-w-2xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Engineering Philosophy</h2>
              <p className="text-lg text-muted-foreground">We don't do black-box solutions. We believe in transparency, maintainability, and empowering your internal teams.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: Code2, title: "Code Excellence", desc: "Rigorous peer reviews, comprehensive testing, and strict adherence to IaC principles ensure rock-solid deployments." },
                { icon: Users, title: "True Partnership", desc: "We embed within your teams, acting as an extension of your engineering organization rather than an external vendor." },
                { icon: Rocket, title: "Pragmatic Innovation", desc: "We leverage cutting-edge tech when it drives ROI, not just for the sake of novelty. Stability always comes first." }
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 rounded-2xl bg-card border border-border shadow-soft-md hover:shadow-soft-xl transition-all duration-300 hover:-translate-y-2"
                >
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6">
                    <item.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* TEAM */}
        <section className="py-24 bg-background">
          <div className="container-custom">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Meet the Leadership</h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              {team.map((member, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="group relative overflow-hidden rounded-3xl bg-card shadow-soft-md hover:shadow-soft-xl transition-shadow duration-300"
                >
                  <div className="aspect-[4/5] overflow-hidden">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent opacity-90" />
                  <div className="absolute bottom-0 left-0 w-full p-8 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="text-2xl font-bold text-white mb-2">{member.name}</h3>
                    <p className="text-primary-foreground/80 font-medium text-lg">{member.role}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* CERTIFICATIONS */}
        <section className="py-24 bg-slate-50">
          <div className="container-custom text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Certifications & Achievements</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-16">
              Our team holds the highest level of certifications across major cloud and data platforms.
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {['AWS Certified Solutions Architect', 'Azure Data Engineer Associate', 'Google Cloud Professional', 'Databricks Certified Developer'].map((cert, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex flex-col items-center p-6 bg-card border border-border rounded-2xl shadow-soft-sm hover:shadow-soft-md transition-all"
                >
                  <Award className="w-10 h-10 text-secondary mb-4" />
                  <span className="text-sm font-semibold text-foreground text-center">{cert}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </motion.div>
  );
};

export default AboutPage;
