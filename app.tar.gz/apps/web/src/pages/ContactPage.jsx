
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const ContactPage = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      toast({
        title: 'Message securely transmitted.',
        description: 'An architect will review your inquiry and reach out within 24 hours.',
      });
      e.target.reset();
      setIsSubmitting(false);
    }, 1200);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col"
    >
      <Helmet>
        <title>Contact an Architect | DataCloud Solutions</title>
        <meta name="description" content="Reach out to discuss your enterprise data architecture or ML deployment requirements." />
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        
        {/* HEADER */}
        <section className="relative py-24 lg:py-32 bg-slate-950 overflow-hidden">
          <div 
            className="absolute inset-0 z-0 parallax-bg opacity-40"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3?q=80&w=2000&auto=format&fit=crop)' }}
          >
            <div className="gradient-overlay" />
          </div>
          
          <div className="container-custom relative z-10 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-white mb-6"
            >
              Start the Conversation
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-slate-300 text-xl max-w-2xl mx-auto"
            >
              Whether you need to untangle legacy data pipelines or scale new AI models, our engineering leadership is ready to assist.
            </motion.p>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="container-custom">
            <div className="grid lg:grid-cols-5 gap-16">
              
              {/* CONTACT FORM */}
              <motion.div 
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                className="lg:col-span-3 bg-card border border-border shadow-soft-xl rounded-3xl p-8 md:p-10 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
                <h3 className="text-3xl font-bold mb-8 tracking-tight relative z-10">Request an Architecture Review</h3>
                <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-foreground/80">Full Name</label>
                      <Input required className="form-input-premium" placeholder="Jane Doe" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-foreground/80">Work Email</label>
                      <Input type="email" required className="form-input-premium" placeholder="jane@company.com" />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-foreground/80">Company</label>
                      <Input className="form-input-premium" placeholder="Acme Corp" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-foreground/80">Primary Interest</label>
                      <Select>
                        <SelectTrigger className="form-input-premium">
                          <SelectValue placeholder="Select an area" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ai">Applied AI & ML</SelectItem>
                          <SelectItem value="data">Data Engineering</SelectItem>
                          <SelectItem value="cloud">Cloud Migration</SelectItem>
                          <SelectItem value="analytics">Advanced Analytics</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground/80">Technical Context</label>
                    <Textarea 
                      required 
                      className="min-h-[150px] resize-none form-input-premium" 
                      placeholder="Briefly describe your current infrastructure and the bottlenecks you are facing..." 
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting} 
                    className="w-full h-14 text-lg rounded-xl bg-primary text-white hover:bg-primary/90 transition-all duration-300 shadow-soft-md hover:shadow-soft-lg hover:-translate-y-1 active:scale-[0.98]"
                  >
                    {isSubmitting ? 'Transmitting...' : (
                      <>Submit Inquiry <Send className="ml-2 w-5 h-5" /></>
                    )}
                  </Button>
                </form>
              </motion.div>

              {/* CONTACT INFO & IMAGE */}
              <motion.div 
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                className="lg:col-span-2 space-y-12"
              >
                <div className="rounded-3xl overflow-hidden shadow-soft-xl h-64 relative group">
                  <img 
                    src="https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa?q=80&w=800&auto=format&fit=crop" 
                    alt="Team collaboration"
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-slate-900/20" />
                </div>

                <div>
                  <h3 className="text-2xl font-bold mb-6 tracking-tight">Direct Contact</h3>
                  <div className="space-y-4">
                    <div className="flex gap-4 items-center p-5 rounded-2xl bg-card border border-border shadow-soft-sm hover:shadow-soft-md transition-all">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                        <Mail className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">Partnerships</p>
                        <a href="mailto:hello@datacloud.com" className="text-muted-foreground hover:text-primary transition-colors">hello@datacloud.com</a>
                      </div>
                    </div>
                    <div className="flex gap-4 items-center p-5 rounded-2xl bg-card border border-border shadow-soft-sm hover:shadow-soft-md transition-all">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                        <Phone className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">General Line</p>
                        <a href="tel:+15551234567" className="text-muted-foreground hover:text-primary transition-colors">+1 (555) 123-4567</a>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>

            </div>
          </div>
        </section>

        <div className="container-custom"><div className="divider-gradient" /></div>

        {/* OFFICE LOCATIONS */}
        <section className="py-24 bg-slate-50">
          <div className="container-custom">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Offices</h2>
              <p className="text-lg text-muted-foreground">Visit us at one of our global engineering hubs.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="rounded-3xl overflow-hidden border border-border shadow-soft-md bg-card group"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1607615896122-6c919f897e55?q=80&w=800&auto=format&fit=crop" 
                    alt="San Francisco Office"
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="p-6 flex gap-4 items-start">
                  <MapPin className="text-primary w-6 h-6 shrink-0 mt-1" />
                  <div>
                    <h4 className="text-xl font-bold text-foreground mb-2">San Francisco (HQ)</h4>
                    <p className="text-muted-foreground">123 Tech Boulevard<br/>San Francisco, CA 94105</p>
                  </div>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="rounded-3xl overflow-hidden border border-border shadow-soft-md bg-card group"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1637622124152-33adfabcc923?q=80&w=800&auto=format&fit=crop" 
                    alt="New York Office"
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="p-6 flex gap-4 items-start">
                  <MapPin className="text-primary w-6 h-6 shrink-0 mt-1" />
                  <div>
                    <h4 className="text-xl font-bold text-foreground mb-2">New York Hub</h4>
                    <p className="text-muted-foreground">456 Data Street, Suite 200<br/>New York, NY 10001</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </motion.div>
  );
};

export default ContactPage;
