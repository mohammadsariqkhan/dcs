
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Linkedin, Mail, Phone, MapPin, ArrowUpRight } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0a0a0a] text-slate-300 relative overflow-hidden">
      {/* Decorative gradient blur */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl pointer-events-none" />
      
      <div className="container-custom relative z-10 pt-20 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-8 mb-16">
          <div className="lg:col-span-4">
            <Link to="/" className="inline-block mb-6">
              <img 
                src="https://horizons-cdn.hostinger.com/c60e2253-d9b6-4e2a-b737-601033c206b8/1997a50f761adbec7778e0057d701fae.png" 
                alt="DataCloud Solutions" 
                className="h-10 w-auto brightness-0 invert opacity-90"
              />
            </Link>
            <p className="text-base leading-relaxed mb-8 max-w-sm text-slate-400">
              Empowering enterprise organizations to unlock the full potential of their data through applied AI, advanced engineering, and cloud-native architecture.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-2 lg:col-start-6">
            <span className="font-semibold text-white mb-6 block tracking-wide uppercase text-sm">Company</span>
            <nav className="flex flex-col gap-4">
              <Link to="/about" className="hover:text-white transition-colors duration-200 flex items-center gap-1 group">
                About Us <ArrowUpRight className="w-3 h-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
              </Link>
              <Link to="/services" className="hover:text-white transition-colors duration-200">Services</Link>
              <Link to="/company" className="hover:text-white transition-colors duration-200">Leadership</Link>
              <Link to="/contact" className="hover:text-white transition-colors duration-200">Contact</Link>
            </nav>
          </div>

          <div className="lg:col-span-2">
            <span className="font-semibold text-white mb-6 block tracking-wide uppercase text-sm">Legal</span>
            <nav className="flex flex-col gap-4">
              <span className="hover:text-white transition-colors duration-200 cursor-pointer">Privacy Policy</span>
              <span className="hover:text-white transition-colors duration-200 cursor-pointer">Terms of Service</span>
              <span className="hover:text-white transition-colors duration-200 cursor-pointer">Cookie Policy</span>
            </nav>
          </div>

          <div className="lg:col-span-3">
            <span className="font-semibold text-white mb-6 block tracking-wide uppercase text-sm">Global Offices</span>
            <div className="flex flex-col gap-6">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 mt-1 text-primary shrink-0" />
                <div>
                  <p className="font-medium text-white mb-1">San Francisco (HQ)</p>
                  <p className="text-sm text-slate-400">123 Tech Boulevard<br/>San Francisco, CA 94105</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 mt-1 text-primary shrink-0" />
                <div>
                  <p className="font-medium text-white mb-1">Inquiries</p>
                  <a href="mailto:hello@datacloud.com" className="text-sm text-slate-400 hover:text-white transition-colors">hello@datacloud.com</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-slate-500">
            © {currentYear} DataCloud Solutions. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <span>Built for Enterprise</span>
            <div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>
            <span>SOC2 Type II Certified</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
