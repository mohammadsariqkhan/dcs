
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const ServiceCard = ({ icon: Icon, title, description, benefits, technologies, image, index, onCTAClick }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group bg-card text-card-foreground rounded-2xl overflow-hidden shadow-soft-md hover:shadow-soft-xl transition-all duration-500 hover:-translate-y-2 border border-border flex flex-col h-full"
    >
      {image && (
        <div className="relative h-48 sm:h-56 overflow-hidden">
          <div className="absolute inset-0 bg-foreground/10 group-hover:bg-transparent transition-colors duration-500 z-10" />
          <img 
            src={image} 
            alt={title} 
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
          />
          <div className="absolute bottom-4 left-4 z-20 p-3 rounded-xl bg-background/90 backdrop-blur-sm shadow-sm text-primary">
            <Icon className="h-6 w-6" />
          </div>
        </div>
      )}

      <div className="p-6 flex flex-col flex-1">
        {!image && (
          <div className="p-3 rounded-xl bg-primary/10 w-fit mb-6 text-primary">
            <Icon className="h-8 w-8" />
          </div>
        )}
        
        <h3 className="text-2xl font-semibold mb-3 tracking-tight">{title}</h3>
        <p className="text-muted-foreground leading-relaxed mb-6 flex-1">
          {description}
        </p>

        {benefits && benefits.length > 0 && (
          <div className="mb-6">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-foreground/80 mb-3">Key Benefits</h4>
            <ul className="space-y-2">
              {benefits.map((benefit, idx) => (
                <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-primary mt-1 text-lg leading-none">•</span>
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {technologies && technologies.length > 0 && (
          <div className="mb-8">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-foreground/80 mb-3">Technologies</h4>
            <div className="flex flex-wrap gap-2">
              {technologies.map((tech, idx) => (
                <span key={idx} className="text-xs px-3 py-1.5 rounded-md bg-muted text-muted-foreground font-medium border border-border/50">
                  {tech}
                </span>
              ))}
            </div>
          </div>
        )}

        <Button 
          onClick={onCTAClick}
          variant="outline"
          className="w-full mt-auto group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary transition-all duration-300 active:scale-[0.98]"
        >
          Explore Solution <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </motion.div>
  );
};

export default ServiceCard;
