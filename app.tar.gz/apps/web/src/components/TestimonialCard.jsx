
import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const TestimonialCard = ({ quote, name, company, rating, image, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="relative glass-card rounded-2xl p-8 break-inside-avoid mb-8"
    >
      <Quote className="absolute top-6 right-6 h-12 w-12 text-primary/10 rotate-180" />
      
      <div className="flex gap-1 mb-6">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            className={`h-4 w-4 ${i < rating ? 'fill-secondary text-secondary' : 'fill-muted text-muted'}`} 
          />
        ))}
      </div>
      
      <p className="text-foreground/90 leading-relaxed mb-8 text-lg relative z-10">
        "{quote}"
      </p>
      
      <div className="flex items-center gap-4 border-t border-border/50 pt-6">
        {image ? (
          <img 
            src={image} 
            alt={name} 
            className="w-12 h-12 rounded-full object-cover shadow-sm ring-2 ring-background"
          />
        ) : (
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg">
            {name.charAt(0)}
          </div>
        )}
        <div>
          <p className="font-semibold text-foreground tracking-tight">{name}</p>
          <p className="text-sm text-muted-foreground">{company}</p>
        </div>
      </div>
    </motion.div>
  );
};

export default TestimonialCard;
