
import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, animate } from 'framer-motion';

const StatCard = ({ number, label, icon: Icon, index }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [displayNumber, setDisplayNumber] = useState(0);

  // Extract numeric part and suffix
  const numMatch = number.toString().match(/(\d+)(.*)/);
  const targetNum = numMatch ? parseInt(numMatch[1], 10) : 0;
  const suffix = numMatch ? numMatch[2] : '';

  useEffect(() => {
    if (isInView) {
      const controls = animate(0, targetNum, {
        duration: 2,
        ease: "easeOut",
        onUpdate: (value) => setDisplayNumber(Math.floor(value)),
      });
      return controls.stop;
    }
  }, [isInView, targetNum]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="relative p-6 rounded-2xl bg-card border border-border shadow-soft-sm hover:shadow-soft-md transition-shadow duration-300"
    >
      <div className="absolute top-0 right-0 p-4 opacity-5">
        {Icon && <Icon className="w-24 h-24" />}
      </div>
      
      <div className="relative z-10 flex flex-col items-start text-left">
        {Icon && (
          <div className="p-3 bg-primary/10 text-primary rounded-xl mb-4">
            <Icon className="w-6 h-6" />
          </div>
        )}
        <div className="text-4xl md:text-5xl font-extrabold text-foreground mb-2 flex items-baseline">
          {displayNumber}
          <span className="text-primary">{suffix}</span>
        </div>
        <p className="text-muted-foreground font-medium text-sm md:text-base uppercase tracking-wider">
          {label}
        </p>
      </div>
    </motion.div>
  );
};

export default StatCard;
